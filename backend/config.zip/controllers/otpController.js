import otpGenerator from 'otp-generator';
const OTP =require("../models/otpModel.js");
const User = require( '../models/userModel.js');

exports.sendOTP = async(req,res) => {
    try{
        const {email} = req.body
    }catch(error){
        console.log(error.message);
        return res.status(500).json({
            success:false,
            error:error.message
        });
    }
};