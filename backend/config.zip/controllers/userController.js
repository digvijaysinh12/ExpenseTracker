import userModel from "../models/userModel";
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import bcrypt from "bcryptjs";

dotenv.config();

let otpStore = {}; // Temporary Storage for OTPs

//configure NodeMailer
const transporter = nodemailer.createTransport({
    service:"gmail",
    port:465,
    secure:true,
    auth:{
        user:process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

//login callback
const loginController = async (req,res) => {
    try{
        const {email,password}  = req.body
        const user = await userModel.findOne({email,password})
        if(!user){
            return req.status(404).send('User Not Found')
        }
        res.status(200).json({
            success:true,
            user
        });
    }catch(error){
        res.status(400).json({
            success:false,
            error
        })
    }
};

//Register Callback
const registerController = async(req,res) => {
    try{
        const {name,email,password} = req.body
        const user = await userModel.findOne({email})
        if(user){
            return res.status(404).json({message:"User Already exists"})
        }

        //Generate OTP
        const otp =  Math.floor(100000 + Math.random() * 900000).toString();
        const otpExpire = Date.now() + 5*60*10000; // OTP expiry time set to 5 minutes from now
        otpStore[email] = {otp,expiry:otpExpire};  // Store OTP and expire time
    
        //Send OTP email
        await transporter.sendMail({
            from:'"ExpenceTracker-App" <expenceTracker67@gmail.com',
            to:email,
            subject: "Your OTP code for Registration in Expence Tracker App",
            text:`Your OTP code is ${otp}. It is valid for 5 minutes`,
        });

        res.status(200).json({
            success:true,
            message:'OTP Send Successfully'
        })

    }catch(error){
        res.status(400).json({
            success:false,
            error
        })
    }
};

//Verify Otp Controller
const verifyOtpController = async(req,res) => {
    try{
        const {name,otp,email,password} = req.body;
        if(otpStore[email]){
            const {otp:storedOtp,expiry} =  otpStore[email];

            //Check if OTP has expired
            if(Date.now()>expiry){
                delete otpStore[email]; // OTP expired, remove from  store
                return res.status(400).json({
                    success:false,
                    message:'OTP has expired. Please request a new OTP'
                })
            }

            // Verify The OTP
            if(storedOtp === otp){
                //Hash password and save user
                const hashedPassword = await bcrypt.hash(password,10);
                const user = new userModel({name,email,password:hashedPassword});
                await user.save();

                //Remove OTP From Store 
                delete otpStore[email];

                res.status(200).json({
                    success:true,
                    message:'User registered sccessfully'
                });
            }else{
                res.status(400).json({
                    success:false,
                    message:'Invalid OTP'
                });
            }
        }else{
            res.status(400).json({
                message:'OTP Not Found. Please Request a New One'
            });
        }
    }catch(error){
        res.status(400).json({
            success:false,
            error
        })
    }
}

export default { loginController  , registerController,verifyOtpController };