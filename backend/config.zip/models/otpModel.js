import mongoose from 'mongoose';
import mailSender from "../utils/mailSender";

const otpSchema = new mongoose.Schema({
    email:{
        type:String,
        required:true,
    },
    otp:{
        type:String,
        required:true,
    },
    createdAt:{
        type:Date,
        default:Date.now,
        expires:60*5 , //The document will be automatically deleted after 5 minutes of its creation time
    },
});

//Define a function to sned emails
async function sendVerificationEmail(email,otp) {
    try{

    }catch(error){
        console.log("Error occured while sending email: ", error);
        throw error ;
    }
}

otpSchema.pre("save",async function (next) {
    console.log("New document saved to database");
    //only send an email when a new document is created
    if(this.isNew){
        await sendVerificationEmail(this.email,this.otp);
    }
    next();
});

module.exports = mongoose.model("OTP",otpSchema)

